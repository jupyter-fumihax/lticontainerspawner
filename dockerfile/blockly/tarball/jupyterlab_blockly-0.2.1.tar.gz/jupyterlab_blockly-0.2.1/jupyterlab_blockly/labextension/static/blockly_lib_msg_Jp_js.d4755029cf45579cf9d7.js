"use strict";
(self["webpackChunkjupyterlab_blockly_extension"] = self["webpackChunkjupyterlab_blockly_extension"] || []).push([["blockly_lib_msg_Jp_js"],{

/***/ "../blockly/lib/msg/Jp.js":
/*!********************************!*\
  !*** ../blockly/lib/msg/Jp.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "setToolboxTitle": () => (/* binding */ setToolboxTitle)
/* harmony export */ });
//
class setToolboxTitle {
    constructor(toolbox) {
        for (let i = 0; i < toolbox.contents.length; i++) {
            if (toolbox.contents[i].hasOwnProperty('name')) {
                let toolboxName = toolbox.contents[i].name;
                if (ToolboxTitle.hasOwnProperty(toolboxName)) {
                    toolbox.contents[i].name = ToolboxTitle[toolboxName];
                }
            }
        }
    }
}
//
const ToolboxTitle = {
    Logic: '論理',
    Loops: '繰返し',
    Math: '数学',
    Text: 'テキスト',
    Lists: 'リスト',
    Color: '色',
    Variables: '変数',
    Functions: '関数',
};


/***/ })

}]);
//# sourceMappingURL=blockly_lib_msg_Jp_js.d4755029cf45579cf9d7.js.map