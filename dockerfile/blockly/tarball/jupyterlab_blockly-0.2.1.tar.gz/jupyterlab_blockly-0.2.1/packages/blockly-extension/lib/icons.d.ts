import { LabIcon } from '@jupyterlab/ui-components';
export declare const blockly_icon: LabIcon;
