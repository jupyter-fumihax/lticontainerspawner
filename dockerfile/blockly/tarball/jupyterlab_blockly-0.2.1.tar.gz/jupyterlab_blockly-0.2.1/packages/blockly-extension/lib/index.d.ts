import { JupyterFrontEndPlugin } from '@jupyterlab/application';
declare const plugins: JupyterFrontEndPlugin<any>[];
export default plugins;
